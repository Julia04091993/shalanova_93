<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Каталог товаров</title>
    <link rel="stylesheet" href="../css/app.css">
</head>
<body>
    <div class="grid-container">
        <div class="basket">
        <img id = 'pic' src="../css/img/svg/Vector.svg" alt="Значок корзины" class="basket-pic">
        <a id = 'bask' onmouseover="this.style.color = '#00A82D'">Корзина</a>
        </div>
        <script>
            document.getElementById('bask').addEventListener("mouseover", basket);
            function basket() {
                document.getElementById('pic').src = '../css/img/svg/Vector-active.svg';
            }
        </script>  
        <div class="catalog__name">Каталог товаров</div>
        <div class="catalog__item" onmouseover="document.getElementById('button').style.display= 'block'"
        onmouseout="document.getElementById('button').style.display= 'none'">
            <img id="pic1" src="../css/img/svg/увлажнитель.svg" alt="Увлажнитель воздуха" class="catalog__item-pic">
            <p class="catalog__item-description">Увлажнитель воздуха STARWIND SHC1322, 3л, белый</p>
            <p class="catalog__item-price">1650 ₽</p>
            <button id='button'class="catalog__item-buy" onclick="this.style.background = '#00A82D'">Добавить в корзину</button>
        </div>
        <div class="catalog__item">
            <img src="../css/img/svg/триммер.svg" alt="Триммер" class="catalog__item-pic">
            <p class="catalog__item-description">Триммер PHILIPS HC3521/15 серебристый/черный</p>
            <p class="catalog__item-price">2290 ₽</p>
        </div>   
        <div class="catalog__item">
            <img src="../css/img/svg/увлажнитель.svg" alt="Увлажнитель воздуха" class="catalog__item-pic">
            <p class="catalog__item-description">Увлажнитель воздуха STARWIND SHC1322, 3л, белый</p>
            <p class="catalog__item-price">1650 ₽</p>
        </div>
        <div class="catalog__item">
            <img src="../css/img/svg/триммер.svg" alt="Триммер" class="catalog__item-pic">
            <p class="catalog__item-description">Триммер PHILIPS HC3521/15 серебристый/черный</p>
            <p class="catalog__item-price">2290 ₽</p>
        </div>
        <div class="catalog__item">
            <img src="../css/img/svg/триммер.svg" alt="Триммер" class="catalog__item-pic">
            <p class="catalog__item-description">Триммер PHILIPS HC3521/15 серебристый/черный</p>
            <p class="catalog__item-price">2290 ₽</p>
        </div>
    </div>
</body>
</html>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Каталог товаров</title>
    <link rel="stylesheet" href="../css/app.css">
</head>
<body>
    <header class="header">
        <div class="basket">
            <img id = 'pic' src="../css/img/svg/Vector.svg" alt="Значок корзины" class="basket-pic">
            <a  href="" id= 'bask' onmouseover="this.style.color = '#00A82D'">Корзина</a>
        </div>
        <script>
            document.getElementById('bask').addEventListener("mouseover", basket);
            function basket() {
                document.getElementById('pic').src = '../css/img/svg/Vector-active.svg';
            }
        </script>
    </header>
    <div  class="basket__name">
        Корзина
    </div>
    <div class="basket__item">
        <img src="../css/img/svg/увлажнитель.svg" alt="товар в корзине" class="basket__item-pic">
        <p class="basket__item-description">Увлажнитель воздуха STARWIND SHC1322, 3л, белый</p>
        <table class="basket__item-table">
            <tr class="basket__item-table">
                <th class="basket__item-table">-</th>
                <th class="basket__item-table">1</th>
                <th class="basket__item-table">+</th>
            </tr>
        </table>
        <!-- <button class="basket__item-decrease">-</button>
        <p class="basket__item-count">1</p>
        <button class="basket__item-increase">+</button> -->
        <p class="basket__item-price">1650 ₽</p>
        <button class="basket__item-delete">X</button>
    </div>
    <div class="basket__item">
        <img src="../css/img/svg/увлажнитель.svg" alt="товар в корзине" class="basket__item-pic">
        <p class="basket__item-description">Увлажнитель воздуха STARWIND SHC1322, 3л, белый</p>
        <button class="basket__item-decrease">-</button>
        <p class="basket__item-count">1</p>
        <button class="basket__item-increase">+</button>
        <p class="basket__item-price">1650 ₽</p>
        <button class="basket__item-delete">X</button>
    </div>
    <div class="basket__sum">
        Cумма 1526 ₽
    </div>
    <form class="basket__form" method="post">
        <p class="basket__form-title">Пожалуйста, представьтесь</p>
        <input type="text" class="basket__form-input" placeholder="Ваше имя" name="name">
        <input type="text" class="basket__form-input" placeholder="Телефон" name="phone">
        <input type="text" class="basket__form-input" placeholder="Email" name="email">
        <input type="submit" class="basket__form-submit" name="send" value="Оформить заказ">
    </form>
   
</body>
</html><?php /**PATH C:\OpenServer\domains\myproject\resources\views/basket.blade.php ENDPATH**/ ?>
<div>
    <? if (isset($err)){?> <div><?=$err;?> </div><?}?>
    <? if (isset($result)){?> <div><?=$result;?> </div><?}?>
    <form action="" method="post">Форма регистрации<br>
        <p><span class="error">* обязательное поле</span></p>
        Логин: <br><input title="Допустимы буквы, цифры и нижнее подчеркивание" type="text" name="login" value=<?=isset($_POST['login']) ? $_POST['login'] : "";?>>
        <?if (isset($regErr["loginErr"])){echo $regErr["loginErr"];} else {?><span class="error">*</span><? } ?><br>
        Пароль: <br><input type="text" name="password" value=<?=isset($_POST['password']) ? $_POST['password'] : "";?>><?if (isset($passworderr)){echo $passworderr;}?>
        <?if (isset($regErr["passwordErr"])){echo $regErr["passwordErr"];} else {?><span class="error">*</span><? } ?><br>
        Имя: <br><input type="text" name="name" value=<?=isset($_POST['name']) ? $_POST['name'] : "";?>>
        <?if (isset($regErr["nameErr"])){echo $regErr["nameErr"];} else {?><span class="error">*</span><? } ?><br>
        Фамилия: <br><input type="text" name="surname" value=<?=isset($_POST['surname']) ? $_POST['surname'] : "";?>>
        <?if (isset($regErr["surnameErr"])){echo $regErr["surnameErr"];} else {?><span class="error">*</span><? } ?><br>
        Дата рождения: <br><input type="date" name="birthday" value=<?=isset($_POST['birthday']) ? $_POST['birthday'] : "";?>>
        <? if (!isset($_POST['birthday'])) {?><span class="error">*</span><? } ?><br>
        Адрес: <br><input type="text" name="address" value=<?=isset($_POST['address']) ? $_POST['address'] : "";?>>
        <?if (isset($regErr["addressErr"])){echo $regErr["addressErr"];} else {?><span class="error">*</span><? } ?><br>
        Телефон: <br><input title="в формате +7..." type="text" name="phone" placeholder="+7 xxx xxx xx xx" value=<?=isset($_POST['phone']) ? $_POST['phone'] : "";?>>
        <?if (isset($regErr["phoneErr"])){echo $regErr["phoneErr"];} else {?><span class="error">*</span><? } ?><br>
        Email: <br><input type="email" name="email" value=<?=isset($_POST['email']) ? $_POST['email'] : "";?>>
        <span class="error">*</span><br>
        <input type="submit" value="Зарегистрироваться" name="send"><br>
        <a href="/hello/">Назад</a> 
    </form> 
</div>
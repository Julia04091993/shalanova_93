<?php 
echo $name . $mypage;

<div>
    <? if (isset($err)){?> <div><?=$err;?> </div><?}?>
    <form action="" method="post">Авторизация<br>
         Логин: <br><input type="text" name="login" value=<?=isset($_POST['login']) ? $_POST['login'] : "";?>><br>
         Пароль: <br><input type="text" name="password" value=<?=isset($_POST['password']) ? $_POST['password'] : "";?>><br>
        <input type="submit" value="Авторизоваться" name="send"><br>
         <a href="/hello/">Назад</a> 
    </form>
</div>
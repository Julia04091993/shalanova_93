<?php
	namespace Project\Controllers;
	use \Core\Controller;
	use \Project\Models\Hello;
	
	class HelloController extends Controller
	{
		public function index() {
			$this->title = 'Авторизация и регистрация на фреймворке';
			
			$hello = (new Hello)->babylek(); // тестовая модель для проверки базы
			
			return $this->render('hello/index');
		}
	}

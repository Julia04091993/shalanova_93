<?php
	namespace Project\Controllers;
	use \Core\Controller;
	use \Project\Models\Reg;
	
	class RegController extends Controller
	{
		public function index() {
			$this->title = 'Зарегистрируйтесь';
			if (isset($_POST["send"])) {
                if (empty($_POST["login"]) || empty($_POST["password"]) || empty($_POST["name"]) ||
                    empty($_POST["surname"]) || empty($_POST["birthday"]) || empty($_POST["address"]) || 
                    empty($_POST["phone"]) || $_POST["phone"] == "+7" || empty($_POST["email"]) ) {
                    return $this->render('reg/index', ['err' => " Заполните все обязательные поля!"]);
                } else {
                    $regErr = [];
                    $login = $this->testinput($_POST["login"]);
                    if (!preg_match("/^[a-zA-Z 0-9_]*$/", $login)) {
                        $regErr['loginErr'] = " Некорректный логин!";
                    }
                    $password = $this->testinput($_POST["password"]);
                    if (!preg_match("/^[a-zA-Z0-9_]*$/", $password)) {
                        $regErr['passwordErr'] = " Некорректный пароль!";
                    } else {
                        $password = md5($password);
                    }
                    $name = $this->testinput($_POST["name"]);
                    if (!preg_match("/^[а-яёА-ЯЁ ]*$/u", $name)) {
                        $regErr['nameErr'] = " Имя должно быть написано на кириллице";
                    }
                    $surname = $this->testinput($_POST["surname"]);
                    if (!preg_match("/^[а-яёА-ЯЁ ]*$/u", $surname)) {
                        $regErr['surnameErr'] = "Фамилия должна быть написана на кириллице";
                    }
                    $address = $this->testinput($_POST["address"]);
                    if (!preg_match("#^[а-яёА-ЯЁ0-9 ,\.\/\-]*$#u", $address)) {
                        $regErr['addressErr'] = "Неверный адрес";
                    }
                    $telephone = $this->testinput($_POST["phone"]);
                    $phone = str_replace(" ", '', $telephone);
                    if (!preg_match("/^[\+0-9]*$/", $phone) || strlen($phone) != 12) {
                        $regErr['phoneErr'] = "Некорректный телефон";
                    }
                    if (empty($regErr)) {
                        $result = (new Reg)->addUser($login, $password, $name, $surname, $_POST["birthday"], $address, $phone, $_POST["email"]);
                        return $this->render('reg/index', ["regErr" => $regErr, "result" => $result]);
                    }

                }
                return $this->render('reg/index', ["regErr" => $regErr]);
            }
			return $this->render('reg/index');
		}
	}
	
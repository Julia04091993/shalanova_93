<?php
	namespace Project\Controllers;
	use \Core\Controller;
	use \Project\Models\Auth;
	
	class AuthController extends Controller
	{
		public function index() {
			$this->title = 'Авторизуйтесь';
			
			if (isset($_POST["send"])) {
                if (empty($_POST["login"]) || empty($_POST["password"])) {
                   return $this->render('auth/index', ['err' => "Введите логин и пароль!"]);
                } else {
					$login = $this->testinput($_POST["login"]);
					$password = $this->testinput($_POST["password"]);
					$password = md5($password);
					$auth = (new Auth)->err($login);
					if ($auth == 0) {
						return $this->render('auth/index', ['err' => "Пользователя с таким логином нет!"]);	
					} elseif ($auth["password"] == $password) {
						return $this->render('auth/index', ['err' => "Авторизация прошла успешно!"]);
					} else {
						return $this->render('auth/index', ['err' => "Неверный пароль!"]);
					}
				}
			}
			return $this->render('auth/index');
		}
	}
	
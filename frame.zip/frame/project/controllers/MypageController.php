<?php
	namespace Project\Controllers;
	use \Core\Controller;
	use \Project\Models\Mypage;
	
	class MypageController extends Controller
	{
		public function index() {
			$this->title = 'задание от бабулека';
			
			$mypage = (new Mypage)->babylek(); // тестовая модель для проверки базы
			
			return $this->render('mypage/index', ['name'=>'Виталя -', "mypage" => $mypage]);
		}
	}

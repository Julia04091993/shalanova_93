<?php
	namespace Project\Models;
	use \Core\Model;
    
	class Reg extends Model
	{   
        public function addUser($login, $password, $name, $surname, $birthday, $address, $phone, $email)
        {
            if (mysqli_query(self::$link, "INSERT INTO `users` (`login`,`password`,`name`, `surname`, `birthday`, `address`, `phone`, `email`) 
            VALUES ('{$login}', '{$password}', '{$name}','{$surname}', '{$birthday}', '{$address}', '{$phone}', '{$email}')")) {
                return "Вы успешно зарегистрировались!";    
            } else {
                return "Произошла ошибка авторизации";
            }
        }
		
	}

<?php
	namespace Project\Models;
	use \Core\Model;
	
	class Mypage extends Model
	{
		public function babylek()
		{
			return ' хитрый сладкий бабулек!';
		}
	}

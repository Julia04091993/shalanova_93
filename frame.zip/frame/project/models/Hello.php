<?php
	namespace Project\Models;
	use \Core\Model;
	
	class Hello extends Model
	{
		public function babylek()
		{
			return 'мой любиымый сладкий бабулек';
		}
	}

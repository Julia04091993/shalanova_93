<?php
	namespace Project\Models;
	use \Core\Model;
    
	class Auth extends Model
	{   
        public function err($login)
        {
            return $this->findOne("SELECT `login`,`password` FROM `users` WHERE `login` = '$login'");
        }
		
	}

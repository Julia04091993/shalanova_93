<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<title><?= $title?></title>
		<style>
			.error {color: #FF0000;}
		</style>
	</head>
	<body>
		<?= $content ?>
	</body>
</html>

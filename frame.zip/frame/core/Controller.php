<?php
	namespace Core;
	
	class Controller
	{
		protected $layout = 'default';
		
		protected function render($view, $data = []) {
			return new Page($this->layout, $this->title, $view, $data);
		}

		protected function testinput($data)
		{
			$data = trim($data);
    		$data = stripslashes($data);
    		$data = htmlspecialchars($data);
    		return $data;
		}
	}
